package com.alex.assistant

import android.animation.ObjectAnimator
import android.animation.PropertyValuesHolder
import android.animation.ValueAnimator
import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.Service
import android.content.Intent
import android.content.pm.ServiceInfo
import android.graphics.PixelFormat
import android.graphics.drawable.GradientDrawable
import android.os.Handler
import android.os.IBinder
import android.os.Looper
import android.provider.Settings
import android.speech.tts.TextToSpeech
import android.speech.tts.UtteranceProgressListener
import android.view.ContextThemeWrapper
import android.view.Gravity
import android.view.LayoutInflater
import android.view.MotionEvent
import android.view.View
import android.view.ViewConfiguration
import android.view.WindowManager
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView
import android.widget.Toast
import java.util.Locale

class AlexService : Service(), AgentHost {

    companion object {
        const val ACTION_STOP = "com.alex.assistant.STOP"
        @Volatile var running = false
        private const val CH = "alex_channel"
    }

    private enum class St { IDLE, LISTEN, AWAKE, THINK, SPEAK }

    private val main = Handler(Looper.getMainLooper())
    private lateinit var wm: WindowManager
    private var view: View? = null
    private lateinit var lp: WindowManager.LayoutParams

    private lateinit var panel: View
    private lateinit var bubble: TextView
    private lateinit var orb: View
    private lateinit var ring: View
    private lateinit var dot: View
    private lateinit var statusTv: TextView
    private lateinit var transcript: TextView
    private lateinit var scroll: ScrollView
    private lateinit var voiceScroll: View
    private lateinit var voiceList: LinearLayout
    private lateinit var btnMic: TextView

    private var capture: AudioCapture? = null
    private var tts: TextToSpeech? = null
    private var ttsReady = false
    private val pendingSpeech = ArrayList<String>()
    private var pending = 0
    private var utt = 0
    private var micOn = true
    @Volatile private var awake = false
    private var minimized = false
    private var savedW = 0
    private var savedH = 0
    private var pulseAnim: ObjectAnimator? = null
    private var agent: Agent? = null
    private val lines = ArrayList<String>()
    private var destroyed = false

    private val sleepRunnable = Runnable { awake = false; if (agent?.running != true) setState(St.LISTEN) }

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        if (intent?.action == ACTION_STOP) { stopSelf(); return START_NOT_STICKY }
        return START_NOT_STICKY
    }

    private fun fail(tag: String, e: Throwable) {
        AlexApp.saveCrash(this, "[$tag] " + AlexApp.trace(e))
        try { Toast.makeText(this, "Ошибка ($tag). Открой Алекса и скопируй её", Toast.LENGTH_LONG).show() } catch (_: Throwable) {}
        stopSelf()
    }

    override fun onCreate() {
        super.onCreate()
        running = true
        wm = getSystemService(WINDOW_SERVICE) as WindowManager
        try { startAsForeground() } catch (e: Throwable) { fail("foreground", e); return }
        if (!Settings.canDrawOverlays(this)) { stopSelf(); return }
        try { buildOverlay() } catch (e: Throwable) { fail("overlay", e); return }
        try { initTts() } catch (e: Throwable) { fail("tts", e); return }
        agent = Agent(this, this)
        setState(St.LISTEN)
        main.postDelayed({
            try { startCapture() } catch (e: Throwable) { fail("mic", e) }
        }, 500)
    }

    override fun onDestroy() {
        destroyed = true
        running = false
        main.removeCallbacksAndMessages(null)
        pulseAnim?.cancel()
        capture?.stop()
        try { tts?.stop(); tts?.shutdown() } catch (_: Exception) {}
        try { view?.let { wm.removeView(it) } } catch (_: Exception) {}
        agent?.cancelled = true
        super.onDestroy()
    }

    private fun startAsForeground() {
        val nm = getSystemService(NotificationManager::class.java)
        nm.createNotificationChannel(NotificationChannel(CH, "Alex", NotificationManager.IMPORTANCE_LOW))
        val stop = PendingIntent.getService(
            this, 1, Intent(this, AlexService::class.java).setAction(ACTION_STOP), PendingIntent.FLAG_IMMUTABLE
        )
        val open = PendingIntent.getActivity(this, 2, Intent(this, MainActivity::class.java), PendingIntent.FLAG_IMMUTABLE)
        @Suppress("DEPRECATION")
        val n = Notification.Builder(this, CH)
            .setSmallIcon(android.R.drawable.ic_btn_speak_now)
            .setContentTitle("Alex слушает")
            .setContentText("Скажи «Алекс» и команду")
            .setContentIntent(open)
            .addAction(android.R.drawable.ic_menu_close_clear_cancel, "Остановить", stop)
            .setOngoing(true)
            .build()
        startForeground(1, n, ServiceInfo.FOREGROUND_SERVICE_TYPE_MICROPHONE)
    }

    // ------------------------------------------------------------ overlay UI

    private fun dp(v: Int) = (v * resources.displayMetrics.density).toInt()

    private fun buildOverlay() {
        val themed = ContextThemeWrapper(this, R.style.Theme_Alex)
        val v = LayoutInflater.from(themed).inflate(R.layout.overlay_alex, null)
        view = v
        panel = v.findViewById(R.id.panel)
        bubble = v.findViewById(R.id.bubble)
        orb = v.findViewById(R.id.orb)
        ring = v.findViewById(R.id.ring)
        dot = v.findViewById(R.id.dot)
        statusTv = v.findViewById(R.id.status)
        transcript = v.findViewById(R.id.transcript)
        scroll = v.findViewById(R.id.scroll)
        voiceScroll = v.findViewById(R.id.voiceScroll)
        voiceList = v.findViewById(R.id.voiceList)
        btnMic = v.findViewById(R.id.btnMic)

        savedW = dp(310); savedH = dp(420)
        lp = WindowManager.LayoutParams(
            savedW, savedH,
            WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or WindowManager.LayoutParams.FLAG_NOT_TOUCH_MODAL,
            PixelFormat.TRANSLUCENT
        ).apply { gravity = Gravity.TOP or Gravity.START; x = dp(16); y = dp(110) }
        wm.addView(v, lp)

        makeDraggable(v.findViewById(R.id.header), null)
        makeDraggable(bubble) { setMinimized(false) }
        v.findViewById<View>(R.id.btnMin).setOnClickListener { setMinimized(true) }
        v.findViewById<View>(R.id.btnClose).setOnClickListener { stopSelf() }
        v.findViewById<View>(R.id.btnVoice).setOnClickListener {
            if (voiceScroll.visibility == View.VISIBLE) voiceScroll.visibility = View.GONE
            else { fillVoices(); voiceScroll.visibility = View.VISIBLE }
        }
        btnMic.setOnClickListener {
            micOn = !micOn
            btnMic.text = if (micOn) "🎤 Слушаю" else "🔇 Микро выкл"
            updatePause()
            setState(if (micOn) St.LISTEN else St.IDLE)
        }
        v.findViewById<View>(R.id.btnStop).setOnClickListener {
            agent?.cancelled = true
            tts?.stop(); pending = 0
            awake = false
            setState(St.LISTEN)
            updatePause()
        }
        orb.setOnClickListener { awake = true; setState(St.AWAKE); main.removeCallbacks(sleepRunnable); main.postDelayed(sleepRunnable, 9000) }
        setupResize(v.findViewById(R.id.btnResize))
    }

    private fun fillVoices() {
        voiceList.removeAllViews()
        val cur = Prefs.voice(this)
        VoiceProfiles.all.forEachIndexed { i, vp ->
            val t = TextView(this).apply {
                text = "${vp.emoji}  ${vp.name}"
                textSize = 15f
                setTextColor(0xFFEAF0FF.toInt())
                setPadding(dp(12), dp(10), dp(12), dp(10))
                setBackgroundResource(if (i == cur) R.drawable.bg_chip_sel else R.drawable.bg_chip)
            }
            val l = LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT)
            l.setMargins(0, dp(3), 0, dp(3))
            t.layoutParams = l
            t.setOnClickListener {
                Prefs.setVoice(this, i)
                voiceScroll.visibility = View.GONE
                speak("Привет! Я Алекс. Теперь я говорю голосом: ${vp.name}.")
            }
            voiceList.addView(t)
        }
    }

    private fun makeDraggable(target: View, onClick: (() -> Unit)?) {
        var sx = 0; var sy = 0; var tx = 0f; var ty = 0f; var moved = false
        val slop = ViewConfiguration.get(this).scaledTouchSlop
        target.setOnTouchListener { _, e ->
            when (e.action) {
                MotionEvent.ACTION_DOWN -> { sx = lp.x; sy = lp.y; tx = e.rawX; ty = e.rawY; moved = false }
                MotionEvent.ACTION_MOVE -> {
                    val dx = e.rawX - tx; val dy = e.rawY - ty
                    if (Math.abs(dx) > slop || Math.abs(dy) > slop) moved = true
                    if (moved) { lp.x = (sx + dx).toInt(); lp.y = (sy + dy).toInt(); safeUpdate() }
                }
                MotionEvent.ACTION_UP -> if (!moved) onClick?.invoke()
            }
            true
        }
    }

    private fun setupResize(handle: View) {
        var rx = 0f; var ry = 0f; var sw = 0; var sh = 0
        handle.setOnTouchListener { _, e ->
            when (e.action) {
                MotionEvent.ACTION_DOWN -> { rx = e.rawX; ry = e.rawY; sw = lp.width; sh = lp.height }
                MotionEvent.ACTION_MOVE -> {
                    val dm = resources.displayMetrics
                    lp.width = (sw + (e.rawX - rx)).toInt().coerceIn(dp(240), dm.widthPixels)
                    lp.height = (sh + (e.rawY - ry)).toInt().coerceIn(dp(260), dm.heightPixels)
                    savedW = lp.width; savedH = lp.height
                    safeUpdate()
                }
            }
            true
        }
    }

    private fun setMinimized(m: Boolean) {
        minimized = m
        panel.visibility = if (m) View.GONE else View.VISIBLE
        bubble.visibility = if (m) View.VISIBLE else View.GONE
        if (m) { lp.width = WindowManager.LayoutParams.WRAP_CONTENT; lp.height = WindowManager.LayoutParams.WRAP_CONTENT }
        else { lp.width = savedW; lp.height = savedH }
        safeUpdate()
    }

    private fun safeUpdate() { try { view?.let { wm.updateViewLayout(it, lp) } } catch (_: Exception) {} }

    private fun setState(s: St) {
        main.post {
            if (destroyed || view == null) return@post
            val (color, label) = when (s) {
                St.IDLE -> 0xFF5B6B9A.toInt() to "Микрофон выключен"
                St.LISTEN -> 0xFF22D3EE.toInt() to "Слушаю — говори «Алекс, …»"
                St.AWAKE -> 0xFF34D399.toInt() to "Говори команду…"
                St.THINK -> 0xFF8B5CF6.toInt() to "Думаю…"
                St.SPEAK -> 0xFFF472B6.toInt() to "Говорю…"
            }
            for (b in listOf(orb, ring, dot)) (b.background.mutate() as GradientDrawable).setColor(color)
            (bubble.background.mutate() as GradientDrawable).setColor(color)
            statusTv.text = label
            pulse(s != St.IDLE)
        }
    }

    private fun pulse(on: Boolean) {
        pulseAnim?.cancel()
        ring.scaleX = 1f; ring.scaleY = 1f
        if (on) {
            pulseAnim = ObjectAnimator.ofPropertyValuesHolder(
                ring,
                PropertyValuesHolder.ofFloat("scaleX", 1f, 1.5f),
                PropertyValuesHolder.ofFloat("scaleY", 1f, 1.5f),
                PropertyValuesHolder.ofFloat("alpha", 0.5f, 0.1f)
            ).apply { duration = 900; repeatCount = ValueAnimator.INFINITE; repeatMode = ValueAnimator.REVERSE; start() }
        } else ring.alpha = 0.2f
    }

    private fun log(who: String, text: String) {
        lines.add("$who $text")
        while (lines.size > 8) lines.removeAt(0)
        transcript.text = lines.joinToString("\n\n")
        scroll.post { scroll.fullScroll(View.FOCUS_DOWN) }
    }

    // ------------------------------------------------------------ AgentHost

    override fun say(text: String) { main.post { if (!destroyed) { log("🤖", text); speak(text) } } }
    override fun status(text: String) { main.post { if (!destroyed && view != null) statusTv.text = text } }
    override fun ghost(on: Boolean) {
        main.post {
            val v = view ?: return@post
            v.alpha = if (on) 0f else 1f
            lp.flags = if (on) lp.flags or WindowManager.LayoutParams.FLAG_NOT_TOUCHABLE
            else lp.flags and WindowManager.LayoutParams.FLAG_NOT_TOUCHABLE.inv()
            safeUpdate()
        }
    }
    override fun heard(text: String) { main.post { if (!destroyed) log("🧑", text) } }
    private fun openFollowUp() {
        if (agent?.engaged == true && pending == 0) {
            awake = true
            main.removeCallbacks(sleepRunnable)
            main.postDelayed(sleepRunnable, 12000)
        }
    }

    override fun finished() {
        main.post {
            if (destroyed) return@post
            openFollowUp()
            setState(if (pending > 0) St.SPEAK else if (micOn) St.LISTEN else St.IDLE)
            main.postDelayed({ updatePause() }, 300)
        }
    }

    // ------------------------------------------------------------ TTS

    private fun initTts() {
        tts = TextToSpeech(this) { code ->
            if (code == TextToSpeech.SUCCESS) {
                val r = tts?.setLanguage(Locale("ru", "RU"))
                if (r == TextToSpeech.LANG_MISSING_DATA || r == TextToSpeech.LANG_NOT_SUPPORTED) tts?.setLanguage(Locale.getDefault())
                tts?.setOnUtteranceProgressListener(object : UtteranceProgressListener() {
                    override fun onStart(id: String?) { main.post { setState(St.SPEAK) } }
                    override fun onDone(id: String?) { main.post { spoken() } }
                    @Deprecated("Deprecated in Java")
                    override fun onError(id: String?) { main.post { spoken() } }
                })
                ttsReady = true
                main.post {
                    pendingSpeech.forEach { speak(it) }
                    pendingSpeech.clear()
                }
            }
        }
    }

    private fun spoken() {
        if (pending > 0) pending--
        if (pending == 0 && !destroyed) {
            setState(if (agent?.running == true) St.THINK else if (micOn) St.LISTEN else St.IDLE)
            openFollowUp()
            main.postDelayed({ updatePause() }, 450)
        }
    }

    private fun speak(text: String) {
        if (!ttsReady) { pendingSpeech.add(text); return }
        val v = VoiceProfiles.all[Prefs.voice(this).coerceIn(0, VoiceProfiles.all.size - 1)]
        tts?.setPitch(v.pitch)
        tts?.setSpeechRate(v.rate)
        pending++
        updatePause()
        utt++
        val res = tts?.speak(text, TextToSpeech.QUEUE_ADD, null, "alex$utt")
        if (res != TextToSpeech.SUCCESS) { pending--; main.postDelayed({ updatePause() }, 300) }
    }

    // ------------------------------------------------------------ own microphone -> Gemini

    private fun updatePause() {
        capture?.paused = !micOn || pending > 0 || agent?.running == true
    }

    private fun startCapture() {
        val c = AudioCapture(
            onSegment = { wav -> onSegment(wav) },
            onLevel = { lvl ->
                val sc = 1f + (lvl.coerceIn(0f, 3000f) / 3000f) * 0.6f
                main.post { if (!destroyed && view != null) { orb.scaleX = sc; orb.scaleY = sc } }
            },
            onVoice = { v -> if (v) main.post { if (!destroyed && view != null && agent?.running != true) statusTv.text = "🎙 Слышу голос…" } },
            onError = { msg -> main.post { if (!destroyed && view != null) statusTv.text = msg } }
        )
        capture = c
        updatePause()
        c.start()
    }

    private fun onSegment(wav: ByteArray) {
        val ag = agent ?: return
        if (pending > 0 || !micOn) return
        if (!ag.claim()) return
        val forced = awake
        main.post {
            awake = false
            main.removeCallbacks(sleepRunnable)
            statusTv.text = "Отправляю в Gemini…"
            setState(St.THINK)
            updatePause()
        }
        Thread { ag.run(wav, forced) }.start()
    }
}
