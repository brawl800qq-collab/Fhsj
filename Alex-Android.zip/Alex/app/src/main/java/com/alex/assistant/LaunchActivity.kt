package com.alex.assistant

import android.app.Activity
import android.content.ClipData
import android.content.ClipboardManager
import android.content.Intent
import android.os.Bundle
import android.widget.Button
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView
import android.widget.Toast
import java.io.File

class LaunchActivity : Activity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val f = File(filesDir, "crash.txt")
        if (!f.exists()) { goMain(); return }
        val trace = try { f.readText().take(7000) } catch (_: Throwable) { "нет данных" }

        val pad = (16 * resources.displayMetrics.density).toInt()
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setBackgroundColor(0xFF0B0F1E.toInt())
            setPadding(pad, pad * 2, pad, pad)
        }
        root.addView(TextView(this).apply {
            text = "Алекс упал. Нажми «Копировать» и отправь текст Claude:"
            setTextColor(0xFFFFFFFF.toInt()); textSize = 16f
        })
        root.addView(Button(this).apply {
            text = "Копировать ошибку"
            setOnClickListener {
                val cm = getSystemService(CLIPBOARD_SERVICE) as ClipboardManager
                cm.setPrimaryClip(ClipData.newPlainText("crash", trace))
                Toast.makeText(this@LaunchActivity, "Скопировано", Toast.LENGTH_SHORT).show()
            }
        })
        root.addView(Button(this).apply {
            text = "Продолжить"
            setOnClickListener { f.delete(); goMain() }
        })
        val tv = TextView(this).apply {
            text = trace
            setTextColor(0xFFFF8A9B.toInt()); textSize = 11f
            setTextIsSelectable(true)
        }
        root.addView(ScrollView(this).apply { addView(tv) }, LinearLayout.LayoutParams(-1, 0, 1f))
        setContentView(root)
    }

    private fun goMain() {
        try { startActivity(Intent(this, MainActivity::class.java)) } catch (_: Throwable) {}
        finish()
    }
}
