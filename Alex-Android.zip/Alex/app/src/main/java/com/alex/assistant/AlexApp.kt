package com.alex.assistant

import android.app.Application
import android.content.Context
import android.content.Intent
import android.os.Build
import android.os.Process
import java.io.File
import java.io.PrintWriter
import java.io.StringWriter

class AlexApp : Application() {

    companion object {
        fun saveCrash(c: Context, text: String) {
            try { File(c.filesDir, "crash.txt").appendText(text + "\n\n-----\n\n") } catch (_: Throwable) {}
        }

        fun trace(e: Throwable): String {
            val sw = StringWriter()
            e.printStackTrace(PrintWriter(sw))
            return ("Android ${Build.VERSION.RELEASE} (API ${Build.VERSION.SDK_INT}), ${Build.MANUFACTURER} ${Build.MODEL}\n\n$sw").take(5000)
        }
    }

    override fun onCreate() {
        super.onCreate()
        Thread.setDefaultUncaughtExceptionHandler { _, e ->
            saveCrash(this, trace(e))
            try {
                startActivity(
                    Intent(this, LaunchActivity::class.java)
                        .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_CLEAR_TASK)
                )
                Thread.sleep(500)
            } catch (_: Throwable) {
            }
            Process.killProcess(Process.myPid())
            System.exit(10)
        }
    }
}
