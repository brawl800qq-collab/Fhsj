package com.alex.assistant

import android.accessibilityservice.AccessibilityService
import android.content.Context
import android.graphics.Bitmap
import org.json.JSONArray
import org.json.JSONObject
import java.io.ByteArrayOutputStream

interface AgentHost {
    fun say(text: String)
    fun status(text: String)
    fun ghost(on: Boolean)
    fun heard(text: String)
    fun finished()
}

class Agent(private val ctx: Context, private val host: AgentHost) {
    @Volatile var cancelled = false
    @Volatile var running = false
    @Volatile var engaged = false
    private val memory = ArrayList<String>()

    companion object {
        private val WAKE = Regex("(?iu)(?<!\\p{L})(алекс|алёкс|alex|алэкс|олекс|элекс)\\p{L}?")
        private val JUNK = listOf("продолжение следует", "спасибо за просмотр", "субтитры", "подписывайтесь", "редактор субтитров")

        private const val SYSTEM = """Ты — Алекс, умный и быстрый голосовой помощник на Android-телефоне пользователя. Говори по-русски, коротко и дружелюбно (1-2 предложения), твой ответ озвучивается вслух.
Тебе дают задачу и (если нужно) скриншот экрана. Выполняй задачу по ОДНОМУ действию за шаг.
Отвечай ТОЛЬКО одним JSON-объектом без пояснений:
{"speech":"что сказать вслух","action":"...","x":0,"y":0,"x2":0,"y2":0,"text":"","app":""}
Координаты x,y — в системе 0..1000 (x слева направо, y сверху вниз) относительно скриншота.
Допустимые action: look (показать мне экран), tap, swipe (из x,y в x2,y2), type (поле text), enter, open_app (поле app — название приложения как на телефоне), back, home, recents, scroll_down, scroll_up, wait, done.
Правила:
- Если это вопрос или разговор — сразу action=done и ответ в speech.
- Приложения открывай через open_app, а не ищи иконку вручную.
- Если для задачи нужно видеть экран — верни action=look (на первом шаге экран не показывается).
- Перед type сначала нажми tap на поле ввода, если оно не в фокусе.
- Когда задача выполнена — action=done и короткий итог в speech.
- Если действие не помогло, не повторяй его — попробуй другое.
- Перед необратимыми действиями (оплата, перевод денег, удаление, отправка важного) не делай их, а спроси подтверждение через action=done.
- speech на промежуточных шагах оставляй пустым или очень коротким."""
    }

    @Synchronized
    fun claim(): Boolean {
        if (running) return false
        running = true
        cancelled = false
        return true
    }

    private fun groqMode() = Prefs.groqKey(ctx).isNotBlank()

    /** Must be called after claim() returned true. */
    fun run(audio: ByteArray, forced: Boolean) {
        engaged = false
        try {
            if (groqMode()) processGroq(audio, forced) else processGemini(audio, forced)
        } catch (e: GeminiClient.GeminiException) {
            val msg = when (e.code) {
                429 -> "Лимит бесплатных запросов закончился. Подожди минутку."
                401, 403 -> "ИИ не принял ключ. Проверь ключ в приложении."
                404 -> "Не нашёл подходящую модель ИИ. Напиши об этом Claude."
                else -> "Ошибка ИИ ${e.code}."
            }
            if (engaged || forced) host.say(msg) else host.status(msg)
        } catch (e: java.io.IOException) {
            if (engaged || forced) host.say("Нет связи с интернетом.") else host.status("Нет связи с интернетом")
        } catch (e: Exception) {
            if (engaged || forced) host.say("Что-то пошло не так.") else host.status("Ошибка обработки")
        } finally {
            running = false
            host.finished()
        }
    }

    // ------------------------------------------------------------ Groq: Whisper -> wake word -> LLM

    private fun processGroq(audio: ByteArray, forced: Boolean) {
        val gkey = Prefs.groqKey(ctx)
        host.status("Распознаю…")
        val text = GroqClient.transcribe(gkey, audio).trim()
        val low = text.lowercase()
        if (text.length < 2 || JUNK.any { low.contains(it) }) { host.status("Слушаю…"); return }

        val m = WAKE.find(text)
        var cmd: String
        if (m != null) {
            val after = text.substring(m.range.last + 1).trim(' ', ',', '.', '!', '?', ':', '-', '—')
            val before = text.substring(0, m.range.first).trim(' ', ',', '.', '!', '?', ':', '-', '—')
            cmd = if (after.isNotBlank()) after else before
        } else if (forced) {
            cmd = text
        } else {
            host.status("Услышал, но не мне: «" + text.take(40) + "»")
            return
        }
        cmd = cmd.trim(' ', ',', '.', '!', '?', ':', '-', '—')
        engaged = true
        if (cmd.isBlank()) { host.say("Слушаю"); return }
        host.heard(cmd)
        loop(cmd)
    }

    // ------------------------------------------------------------ Gemini fallback (audio straight to Gemini)

    private fun processGemini(audio: ByteArray, forced: Boolean) {
        val key = Prefs.apiKey(ctx)
        if (key.isBlank()) { host.say("Вставь ключ Groq или Gemini в настройках приложения."); return }
        host.status("Слушаю…")
        val intro = StringBuilder()
        if (memory.isNotEmpty()) intro.append("Недавний разговор:\n").append(memory.joinToString("\n")).append("\n\n")
        intro.append("К сообщению приложена запись голоса пользователя. Добавь в JSON поля \"heard\" (дословный текст речи) и \"for_alex\" (true/false). ")
        intro.append(
            if (forced) "Пользователь сам нажал кнопку, поэтому for_alex=true. "
            else "for_alex=true только если пользователь обращается к Алексу (звучит имя «Алекс»/«Alex») или явно продолжает диалог; фоновые разговоры и шум — for_alex=false (action=done). "
        )
        intro.append("Если это просто вопрос — ответь в speech и action=done. Если нужно действовать на телефоне — action=look.")
        val j = parse(askGemini(key, intro.toString(), null, audio))
        val heard = j.optString("heard", "").trim()
        val forAlex = forced || j.optBoolean("for_alex", false)
        if (!forAlex) {
            host.status(if (heard.isBlank()) "Слушаю…" else "Услышал, но не мне: «" + heard.take(40) + "»")
            return
        }
        if (heard.isBlank()) { host.status("Не расслышал"); return }
        engaged = true
        host.heard(heard)
        val action = j.optString("action", "done")
        val speech = j.optString("speech", "").trim()
        if (action == "done" || action == "none" || action == "") {
            if (speech.isNotEmpty()) host.say(speech)
            remember(heard, speech)
            return
        }
        loop(heard)
    }

    private fun askGemini(key: String, text: String, jpeg: ByteArray?, audio: ByteArray? = null): String {
        val saved = Prefs.model(ctx)
        val cands = listOf(saved, "gemini-flash-latest", "gemini-3-flash-preview", "gemini-3.1-flash-lite", "gemini-2.5-flash").distinct()
        var last: GeminiClient.GeminiException? = null
        for (m in cands) {
            try {
                val r = GeminiClient.generate(key, m, SYSTEM, text, jpeg, audio)
                if (m != saved) Prefs.setModel(ctx, m)
                return r
            } catch (e: GeminiClient.GeminiException) {
                if (e.code == 404) { last = e; continue }
                throw e
            }
        }
        throw last ?: GeminiClient.GeminiException(404, "no model")
    }

    private fun modelProblem(e: GeminiClient.GeminiException): Boolean {
        val msg = (e.message ?: "").lowercase()
        return e.code == 404 ||
            (e.code == 400 && (msg.contains("decommission") || msg.contains("does not exist") || msg.contains("not found") ||
                (msg.contains("image") && msg.contains("support"))))
    }

    private fun tryGroq(key: String, m: String, text: String, jpeg: ByteArray?): String {
        if (m.contains("qwen")) {
            try {
                return GroqClient.chat(key, m, SYSTEM, text, jpeg, "none")
            } catch (e: GeminiClient.GeminiException) {
                if (e.code != 400 || modelProblem(e)) throw e
            }
        }
        return GroqClient.chat(key, m, SYSTEM, text, jpeg, null)
    }

    private fun askGroq(text: String, jpeg: ByteArray?): String {
        val key = Prefs.groqKey(ctx)
        val saved = Prefs.groqModel(ctx)
        val queue = ArrayDeque<String>()
        queue.addAll(listOf(saved, "qwen/qwen3.8-27b", "qwen/qwen3.6-27b",
            "meta-llama/llama-4-scout-17b-16e-instruct", "meta-llama/llama-4-maverick-17b-128e-instruct"))
        val tried = HashSet<String>()
        var discovered = false
        var last: GeminiClient.GeminiException? = null
        while (queue.isNotEmpty()) {
            val m = queue.removeFirst()
            if (!tried.add(m)) continue
            try {
                val r = tryGroq(key, m, text, jpeg)
                if (m != saved) Prefs.setGroqModel(ctx, m)
                return r
            } catch (e: GeminiClient.GeminiException) {
                if (!modelProblem(e)) throw e
                last = e
                if (queue.isEmpty() && !discovered) {
                    discovered = true
                    try {
                        val hints = listOf("qwen", "llama-4", "vision", "-vl", "scout", "maverick")
                        GroqClient.listModels(key)
                            .filter { id -> !tried.contains(id) && hints.any { id.contains(it) } &&
                                !id.contains("whisper") && !id.contains("guard") && !id.contains("tts") }
                            .forEach { queue.add(it) }
                    } catch (_: Exception) {}
                }
            }
        }
        throw last ?: GeminiClient.GeminiException(404, "no model")
    }

    private fun llm(text: String, jpeg: ByteArray?): String =
        if (groqMode()) askGroq(text, jpeg) else askGemini(Prefs.apiKey(ctx), text, jpeg, null)

    // ------------------------------------------------------------ action loop

    private fun remember(goal: String, speech: String) {
        memory.add("Пользователь: $goal")
        if (speech.isNotEmpty()) memory.add("Алекс: $speech")
        while (memory.size > 8) memory.removeAt(0)
    }

    private fun loop(goal: String) {
        val acc = AlexAccessibilityService.instance
        val dm = ctx.resources.displayMetrics
        val history = ArrayList<String>()
        var lastSpeech = ""
        var useShot = false
        val maxSteps = if (acc == null) 1 else 14
        var step = 0

        while (step < maxSteps) {
            step++
            if (cancelled) { host.say("Остановился."); break }
            var jpeg: ByteArray? = null
            var w = dm.widthPixels
            var h = dm.heightPixels
            if (acc != null && useShot) {
                host.status("Смотрю на экран…")
                host.ghost(true); Thread.sleep(220)
                val bmp = acc.screenshotBlocking()
                host.ghost(false)
                if (bmp != null) { w = bmp.width; h = bmp.height; jpeg = toJpeg(bmp) }
            }
            if (cancelled) { host.say("Остановился."); break }
            host.status("Думаю…")
            val j = parse(llm(prompt(goal, step, history, jpeg != null, acc != null), jpeg))
            val speech = j.optString("speech", "").trim()
            if (speech.isNotEmpty()) { host.say(speech); lastSpeech = speech }
            val action = j.optString("action", "done")
            if (action == "done" || action == "none" || action == "" || acc == null) break
            if (action == "look") { useShot = true; continue }
            if (cancelled) { host.say("Остановился."); break }

            host.status("Делаю: $action")
            host.ghost(true); Thread.sleep(150)
            val desc: String = when (action) {
                "tap" -> { acc.tap(cx(j, "x", w), cx(j, "y", h)); "нажал (${j.optInt("x")},${j.optInt("y")})" }
                "swipe" -> { acc.swipe(cx(j, "x", w), cx(j, "y", h), cx(j, "x2", w), cx(j, "y2", h)); "свайп" }
                "scroll_down" -> { acc.swipe(w * .5f, h * .72f, w * .5f, h * .28f); "прокрутил вниз" }
                "scroll_up" -> { acc.swipe(w * .5f, h * .28f, w * .5f, h * .72f); "прокрутил вверх" }
                "type" -> {
                    val t = j.optString("text", "")
                    if (acc.typeText(t)) "ввёл текст «$t»" else "не смог ввести текст (нет активного поля)"
                }
                "enter" -> if (acc.pressEnter()) "нажал Enter" else "Enter не сработал"
                "open_app" -> {
                    val a = j.optString("app", "")
                    if (acc.openApp(a)) "открыл приложение $a" else "приложение $a не найдено"
                }
                "back" -> { acc.performGlobalAction(AccessibilityService.GLOBAL_ACTION_BACK); "назад" }
                "home" -> { acc.performGlobalAction(AccessibilityService.GLOBAL_ACTION_HOME); "домой" }
                "recents" -> { acc.performGlobalAction(AccessibilityService.GLOBAL_ACTION_RECENTS); "недавние" }
                "wait" -> { Thread.sleep(1500); "подождал" }
                else -> "неизвестное действие $action"
            }
            Thread.sleep(300)
            host.ghost(false)
            history.add(desc)
            useShot = true
            Thread.sleep(900)
        }
        remember(goal, lastSpeech)
    }

    private fun prompt(goal: String, step: Int, history: List<String>, hasImage: Boolean, canSee: Boolean): String {
        val sb = StringBuilder()
        if (memory.isNotEmpty()) sb.append("Недавний разговор:\n").append(memory.joinToString("\n")).append("\n\n")
        sb.append("Задача пользователя: ").append(goal).append("\n")
        sb.append(
            when {
                hasImage -> "К сообщению приложен текущий скриншот экрана.\n"
                canSee -> "Экран сейчас не показан. Если для задачи нужно его видеть — верни action=look. Если хватает действия без экрана (open_app, home, back) или это просто вопрос — действуй сразу.\n"
                else -> "Управление телефоном не включено — только отвечай словами.\n"
            }
        )
        if (history.isNotEmpty()) sb.append("Уже сделано: ").append(history.joinToString("; ")).append("\n")
        sb.append("Шаг ").append(step).append(". Верни JSON со следующим действием.")
        return sb.toString()
    }

    private fun parse(raw: String): JSONObject {
        val s = raw.replace(Regex("(?s)<think>.*?</think>"), "").trim().removePrefix("```json").removePrefix("```").removeSuffix("```").trim()
        return try {
            if (s.startsWith("[")) JSONArray(s).getJSONObject(0) else JSONObject(s)
        } catch (e: Exception) {
            try {
                JSONObject(s.substring(s.indexOf('{'), s.lastIndexOf('}') + 1))
            } catch (e2: Exception) {
                JSONObject().put("speech", s).put("action", "done")
            }
        }
    }

    private fun cx(j: JSONObject, k: String, size: Int): Float =
        (j.optDouble(k, 500.0) / 1000.0 * size).toFloat().coerceIn(0f, size - 1f)

    private fun toJpeg(src: Bitmap): ByteArray {
        val max = 1000f
        val scale = minOf(1f, max / maxOf(src.width, src.height))
        val b = if (scale < 1f) Bitmap.createScaledBitmap(src, (src.width * scale).toInt(), (src.height * scale).toInt(), true) else src
        val out = ByteArrayOutputStream()
        b.compress(Bitmap.CompressFormat.JPEG, 70, out)
        return out.toByteArray()
    }
}
