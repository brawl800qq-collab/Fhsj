package com.alex.assistant

import android.content.Context

object Prefs {
    private fun sp(c: Context) = c.getSharedPreferences("alex_prefs", Context.MODE_PRIVATE)
    fun apiKey(c: Context): String = sp(c).getString("key", "") ?: ""
    fun setApiKey(c: Context, v: String) = sp(c).edit().putString("key", v.trim()).apply()
    fun model(c: Context): String = sp(c).getString("model", "gemini-flash-latest") ?: "gemini-flash-latest"
    fun setModel(c: Context, v: String) = sp(c).edit().putString("model", v.trim()).apply()
    fun voice(c: Context): Int = sp(c).getInt("voice", 0)
    fun setVoice(c: Context, i: Int) = sp(c).edit().putInt("voice", i).apply()
    fun groqKey(c: Context): String = sp(c).getString("groq", "") ?: ""
    fun setGroqKey(c: Context, v: String) = sp(c).edit().putString("groq", v.trim()).apply()
    fun groqModel(c: Context): String =
        sp(c).getString("gmodel", "qwen/qwen3.8-27b") ?: "qwen/qwen3.8-27b"
    fun setGroqModel(c: Context, v: String) = sp(c).edit().putString("gmodel", v.trim()).apply()
}
